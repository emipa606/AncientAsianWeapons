# eatKenny-AncientAsianWeapons-zh
Chinese translation for the eatKenny's Ancient Asian Weapons mods.

This mod adds some ancient asian weapons.

Author: eatKenny

[Ludeon forum](https://ludeon.com/forums/index.php?topic=26723.0)

# License
This mod is licensed under the Creative Commons Attribution-ShareAlike 4.0 International license.
